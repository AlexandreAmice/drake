---
title: Website Third-Party Licenses
---

Please review the following licenses for third-party assets use for this
website:

* [`third_party/dracula/LICENSE.txt`](third_party/dracula/LICENSE.txt)
* [`third_party/github-styling/LICENSE.txt`](third_party/github-styling/LICENSE.txt)
* [`third_party/images/GitHub-Mark.README.txt`](third_party/images/GitHub-Mark.README.txt)
* [`third_party/pylons/LICENSE.txt`](third_party/pylons/LICENSE.txt)
