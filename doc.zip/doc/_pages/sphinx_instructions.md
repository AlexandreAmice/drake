---
title: Sphinx Instructions
---

This section contains instructions on how to use Sphinx with Drake.
Sphinx is the framework for generating Drake's
[website](https://drake.mit.edu/).


# Sphinx Website Generation

To generate and view Drake's website, see the
[Documentation Generation Instructions](/documentation_instructions.html).
