---
title: Trademarks
---

All trademarks, logos and brand names are the property of their respective
owners.

MOSEK™ is a trademark of [MOSEK](https://www.mosek.com/) and is mentioned in
Drake's documentation under a license from [MOSEK](https://www.mosek.com/).

[ROS™ and ROS 2™](https://www.ros.org/) are trademarks of
[Open Robotics](https://www.openrobotics.org/).
<!--
Note: Both "ROS 2" and "ROS2" appear in the wild, e.g.
"ROS 2": https://www.ros.org/
"ROS2": https://www.ros.org/imgs/ROSBrandGuide.pdf
-->
