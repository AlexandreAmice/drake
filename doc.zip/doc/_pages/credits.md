---
title: Credits
---

The Drake project was started by Russ Tedrake and the members of the
[Robot Locomotion Group](http://groups.csail.mit.edu/locomotion/index.html) at MIT
and the [Robotics Division](https://www.tri.global/our-work/robotics/) at
Toyota Research Institute.  Many other people have since contributed their
talents to help make Drake successful.  Here's an alphabetical list: (note to contributors: *do add yourself*)

{% comment %} 
this is modeled directly, and shamelessly, on: http://eigen.tuxfamily.org/index.php?title=Main_Page#Credits
{% endcomment %}

* Alexandre Amice
* Andy Barry
* Alejandro Castro
* John Carter
* Mmanu Chaturvedi
* Rick Cory
* Eric Cousineau
* Sean Curtis
* Sam Creasey
* Hongkai Dai
* Jonathan DeCastro
* Robin Deits
* Evan Drumwright
* Maurice Fallon
* Siyuan Feng
* Moritz Fischer-Gundlach
* Liang Fok
* David German
* Lucy Gibson
* Grant Gould
* Zhaoyuan Gu
* Damrong Guoy
* Xuchen Han
* Kunimatsu Hashimoto
* Bill Hoffman
* Greg Izatt
* Brad King
* Twan Koolen
* Soonho Kong
* Scott Kuindersma
* Naveen Kuppuswamy
* Benoit Landry
* Dominic Liao-McPherson
* Lucas Manuelli
* Matt Marjanovic
* Pat Marion
* Joseph Masterjohn
* Dale McConachie
* Betsy McPhail
* Paul Mitiguy
* Jeremy Nimmer
* Mark Petersen
* Michael Posa
* Rick Poyner
* Ante Qu
* Michael Sherman
* Jamie Snape
* [Russ Tedrake](http://people.csail.mit.edu/russt/)
* Belinda Teh
* Andres Valenzuela
* [David von Wrangel](https://www.davidvonwrangel.com/)
* Matthew Woehlke
* Huihua Zhao
