---
title: Ubuntu
---

Prerequisite setup is automated, simply run:

```
sudo ./setup/ubuntu/install_prereqs.sh
```
