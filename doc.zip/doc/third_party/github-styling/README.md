The following files were copied from
<https://github.com/sindresorhus/github-markdown-css/blob/888d5a03223a2c14a8d3eb40e90a22f62469a46b>:

- `github-markdown.css`
- `LICENSE.md` (renamed from `license`)
