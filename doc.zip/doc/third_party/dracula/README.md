Artifacts taken from: <br/>
<https://github.com/dracula/pygments/blob/fee9ed561/dracula.css>
