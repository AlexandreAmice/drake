This `doc/third_party` directory contains software and artifacts that are
housed alongside Drake, but were not authored by the Drake developers or TRI.

The artifacts here typically have different copyright ownership and licensing
terms than the rest of Drake, and those terms can be found in the license and
readme files associated with those files.

All licenses should be served by Jekyll, and be reachable by
`/doc/_pages/website_license.md`.
