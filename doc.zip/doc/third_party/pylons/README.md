The following artifacts were taken from
<https://github.com/Pylons/pylons-sphinx-themes/tree/8ec0f433a218a927d1001a5a793459addd1dcd92>:

* `CONTRIBUTORS.txt`
* `LICENSE.txt` - This license appears similar to ZPL-2.0, with a clause
  removed.
* `dialg-warning.png`
* `dialog-note.png`
* `pylons.css` - derived from `pylons_sphinx_themes/pylons/static/pylons.css_t`
